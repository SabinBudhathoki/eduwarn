import { Course } from '../types/course';

export const courses: Course[] = [
  {
    id: 1,
    title: 'Machine Learning Fundamentals',
    description: 'Build ML models from scratch and learn core concepts through hands-on projects',
    projects: 15,
    hours: 40,
    image: 'https://images.unsplash.com/photo-1555949963-aa79dcee981c?auto=format&fit=crop&q=80',
    progress: 65,
    curriculum: {
      overview: 'Master the fundamentals of Machine Learning through hands-on projects. Learn to build and train models, work with data, and implement real-world ML solutions.',
      prerequisites: ['Basic Python knowledge', 'Fundamental mathematics', 'Basic statistics'],
      projects: [
        {
          id: 1,
          title: 'Linear Regression from Scratch',
          description: 'Build a linear regression model without using any ML libraries to understand the core concepts.',
          difficulty: 'Beginner',
          duration: '2-3 hours',
          technologies: ['Python', 'NumPy', 'Matplotlib']
        },
        {
          id: 2,
          title: 'Image Classification with CNN',
          description: 'Create a Convolutional Neural Network to classify images using PyTorch.',
          difficulty: 'Intermediate',
          duration: '4-5 hours',
          technologies: ['Python', 'PyTorch', 'CNN']
        }
      ]
    }
  },
  {
    id: 2,
    title: 'Full Stack Web Development',
    description: 'Master modern web development with React, Node.js, and cloud technologies',
    projects: 20,
    hours: 60,
    image: 'https://images.unsplash.com/photo-1547658719-da2b51169166?auto=format&fit=crop&q=80',
    curriculum: {
      overview: 'Become a full-stack developer by mastering both frontend and backend technologies. Build complete web applications from scratch.',
      prerequisites: ['HTML & CSS basics', 'JavaScript fundamentals'],
      projects: [
        {
          id: 1,
          title: 'Real-time Chat Application',
          description: 'Build a real-time chat app using React and WebSocket.',
          difficulty: 'Intermediate',
          duration: '6-8 hours',
          technologies: ['React', 'WebSocket', 'Node.js']
        }
      ]
    }
  },
  {
    id: 3,
    title: 'Mobile App Development',
    description: 'Learn to build cross-platform mobile applications using React Native',
    projects: 12,
    hours: 45,
    image: 'https://images.unsplash.com/photo-1512941937669-90a1b58e7e9c?auto=format&fit=crop&q=80',
    curriculum: {
      overview: 'Master mobile app development using React Native. Build real-world apps for both iOS and Android platforms.',
      prerequisites: ['JavaScript/React knowledge', 'Basic mobile design principles'],
      projects: [
        {
          id: 1,
          title: 'Social Media App',
          description: 'Build a fully functional social media app with authentication and real-time updates.',
          difficulty: 'Advanced',
          duration: '10-12 hours',
          technologies: ['React Native', 'Firebase', 'Redux']
        }
      ]
    }
  },
  {
    id: 4,
    title: 'Cloud Computing & DevOps',
    description: 'Master cloud services and DevOps practices with hands-on projects',
    projects: 10,
    hours: 50,
    image: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&q=80',
    curriculum: {
      overview: 'Learn cloud computing concepts and DevOps practices through practical projects.',
      prerequisites: ['Basic Linux commands', 'Programming fundamentals'],
      projects: [
        {
          id: 1,
          title: 'Microservices Architecture',
          description: 'Build and deploy a microservices-based application using Docker and Kubernetes.',
          difficulty: 'Advanced',
          duration: '8-10 hours',
          technologies: ['Docker', 'Kubernetes', 'AWS']
        }
      ]
    }
  }
];