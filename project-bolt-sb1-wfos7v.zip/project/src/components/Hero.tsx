import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Rocket, Users, Code, Brain } from 'lucide-react';

export default function Hero() {
  const navigate = useNavigate();

  return (
    <div className="relative bg-indigo-900 text-white py-16">
      <div className="absolute inset-0">
        <img
          src="https://images.unsplash.com/photo-1517694712202-14dd9538aa97?auto=format&fit=crop&q=80"
          alt="Hero background"
          className="w-full h-full object-cover opacity-10"
        />
      </div>
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h1 className="text-4xl md:text-6xl font-bold mb-6">
            Learn to Code Through Projects
          </h1>
          <p className="text-xl md:text-2xl mb-8 text-indigo-200">
            Master programming skills by building real-world applications
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <button 
              onClick={() => navigate('/course/1')}
              className="bg-white text-indigo-900 px-8 py-3 rounded-md font-semibold hover:bg-indigo-100 transition-colors duration-300"
            >
              Start Learning
            </button>
            <button 
              onClick={() => navigate('/curriculum')}
              className="border-2 border-white px-8 py-3 rounded-md font-semibold hover:bg-white hover:text-indigo-900 transition-colors duration-300"
            >
              View Curriculum
            </button>
          </div>
        </div>
        
        <div className="mt-16 grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="text-center">
            <div className="bg-indigo-800 p-4 rounded-lg inline-block mb-4">
              <Code className="h-8 w-8" />
            </div>
            <h3 className="text-lg font-semibold mb-2">100+ Projects</h3>
            <p className="text-indigo-200">Learn by building real applications</p>
          </div>
          <div className="text-center">
            <div className="bg-indigo-800 p-4 rounded-lg inline-block mb-4">
              <Brain className="h-8 w-8" />
            </div>
            <h3 className="text-lg font-semibold mb-2">Multiple Domains</h3>
            <p className="text-indigo-200">Web, ML, Mobile & More</p>
          </div>
          <div className="text-center">
            <div className="bg-indigo-800 p-4 rounded-lg inline-block mb-4">
              <Users className="h-8 w-8" />
            </div>
            <h3 className="text-lg font-semibold mb-2">Community</h3>
            <p className="text-indigo-200">Learn with fellow developers</p>
          </div>
          <div className="text-center">
            <div className="bg-indigo-800 p-4 rounded-lg inline-block mb-4">
              <Rocket className="h-8 w-8" />
            </div>
            <h3 className="text-lg font-semibold mb-2">Career Ready</h3>
            <p className="text-indigo-200">Industry relevant skills</p>
          </div>
        </div>
      </div>
    </div>
  );
}