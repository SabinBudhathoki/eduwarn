import React from 'react';
import { Clock, Code2, ArrowRight } from 'lucide-react';
import { Project } from '../types/course';

interface ProjectCardProps {
  project: Project;
  onStart: () => void;
}

export default function ProjectCard({ project, onStart }: ProjectCardProps) {
  return (
    <div className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow">
      <h3 className="text-xl font-semibold mb-2">{project.title}</h3>
      <p className="text-gray-600 mb-4">{project.description}</p>
      
      <div className="flex items-center gap-4 mb-4">
        <div className="flex items-center">
          <Clock className="w-4 h-4 text-gray-400 mr-2" />
          <span className="text-sm text-gray-600">{project.duration}</span>
        </div>
        <div className="flex items-center">
          <Code2 className="w-4 h-4 text-gray-400 mr-2" />
          <span className="text-sm text-gray-600">{project.difficulty}</span>
        </div>
      </div>
      
      <div className="mb-4">
        <div className="flex flex-wrap gap-2">
          {project.technologies.map((tech, index) => (
            <span 
              key={index}
              className="px-2 py-1 bg-indigo-100 text-indigo-700 rounded-full text-sm"
            >
              {tech}
            </span>
          ))}
        </div>
      </div>
      
      <button
        onClick={onStart}
        className="w-full bg-indigo-600 text-white py-2 px-4 rounded-md hover:bg-indigo-700 transition-colors duration-300 flex items-center justify-center"
      >
        Start Project
        <ArrowRight className="ml-2 h-4 w-4" />
      </button>
    </div>
  );
}