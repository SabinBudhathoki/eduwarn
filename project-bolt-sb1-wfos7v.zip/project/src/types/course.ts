export interface Project {
  id: number;
  title: string;
  description: string;
  difficulty: 'Beginner' | 'Intermediate' | 'Advanced';
  duration: string;
  technologies: string[];
}

export interface Course {
  id: number;
  title: string;
  description: string;
  projects: number;
  hours: number;
  image: string;
  progress?: number;
  curriculum: {
    overview: string;
    prerequisites: string[];
    projects: Project[];
  };
}