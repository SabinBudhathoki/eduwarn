import React from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, BookOpen, CheckCircle, Layout } from 'lucide-react';
import { courses } from '../data/courses';
import ProjectCard from '../components/ProjectCard';

export default function CoursePage() {
  const { courseId } = useParams();
  const navigate = useNavigate();
  
  const course = courses.find(c => c.id === Number(courseId));
  
  if (!course) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-gray-900">Course not found</h2>
          <button
            onClick={() => navigate('/')}
            className="mt-4 inline-flex items-center text-indigo-600 hover:text-indigo-800"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Home
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-indigo-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <button
            onClick={() => navigate('/')}
            className="inline-flex items-center text-indigo-200 hover:text-white mb-6"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Courses
          </button>
          
          <h1 className="text-4xl font-bold mb-4">{course.title}</h1>
          <p className="text-xl text-indigo-200 mb-6">{course.description}</p>
          
          <div className="flex flex-wrap gap-6">
            <div className="flex items-center">
              <Layout className="h-5 w-5 mr-2" />
              <span>{course.projects} Projects</span>
            </div>
            <div className="flex items-center">
              <BookOpen className="h-5 w-5 mr-2" />
              <span>{course.hours} Hours</span>
            </div>
            {course.progress && (
              <div className="flex items-center">
                <CheckCircle className="h-5 w-5 mr-2" />
                <span>{course.progress}% Complete</span>
              </div>
            )}
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="bg-white rounded-lg shadow-md p-6 mb-8">
          <h2 className="text-2xl font-bold mb-4">Course Overview</h2>
          <p className="text-gray-600 mb-6">{course.curriculum.overview}</p>
          
          <h3 className="text-xl font-semibold mb-3">Prerequisites</h3>
          <ul className="list-disc list-inside text-gray-600 mb-4">
            {course.curriculum.prerequisites.map((prereq, index) => (
              <li key={index}>{prereq}</li>
            ))}
          </ul>
        </div>

        <h2 className="text-2xl font-bold mb-6">Course Projects</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {course.curriculum.projects.map((project) => (
            <ProjectCard
              key={project.id}
              project={project}
              onStart={() => navigate(`/course/${courseId}/project/${project.id}`)}
            />
          ))}
        </div>
      </div>
    </div>
  );
}