import React from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, Clock, Code2 } from 'lucide-react';
import { courses } from '../data/courses';

export default function ProjectPage() {
  const { courseId, projectId } = useParams();
  const navigate = useNavigate();
  
  const course = courses.find(c => c.id === Number(courseId));
  const project = course?.curriculum.projects.find(p => p.id === Number(projectId));
  
  if (!course || !project) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-gray-900">Project not found</h2>
          <button
            onClick={() => navigate('/')}
            className="mt-4 inline-flex items-center text-indigo-600 hover:text-indigo-800"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Home
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-indigo-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <button
            onClick={() => navigate(`/course/${courseId}`)}
            className="inline-flex items-center text-indigo-200 hover:text-white mb-6"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Course
          </button>
          
          <h1 className="text-4xl font-bold mb-4">{project.title}</h1>
          <p className="text-xl text-indigo-200 mb-6">{project.description}</p>
          
          <div className="flex flex-wrap gap-6">
            <div className="flex items-center">
              <Clock className="h-5 w-5 mr-2" />
              <span>{project.duration}</span>
            </div>
            <div className="flex items-center">
              <Code2 className="h-5 w-5 mr-2" />
              <span>{project.difficulty}</span>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="bg-white rounded-lg shadow-md p-6">
          <h2 className="text-2xl font-bold mb-6">Project Details</h2>
          
          <div className="mb-8">
            <h3 className="text-xl font-semibold mb-4">Technologies Used</h3>
            <div className="flex flex-wrap gap-2">
              {project.technologies.map((tech, index) => (
                <span 
                  key={index}
                  className="px-3 py-1 bg-indigo-100 text-indigo-700 rounded-full"
                >
                  {tech}
                </span>
              ))}
            </div>
          </div>
          
          <div className="space-y-6">
            <div>
              <h3 className="text-xl font-semibold mb-4">Project Steps</h3>
              <div className="prose max-w-none">
                <ol className="list-decimal list-inside space-y-4">
                  <li>Set up your development environment</li>
                  <li>Clone the starter code repository</li>
                  <li>Install project dependencies</li>
                  <li>Follow the step-by-step tutorial</li>
                  <li>Complete the coding challenges</li>
                  <li>Submit your solution for review</li>
                </ol>
              </div>
            </div>
            
            <div className="pt-6">
              <button className="w-full bg-indigo-600 text-white py-3 px-4 rounded-md hover:bg-indigo-700 transition-colors duration-300">
                Start Coding
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}